<?php 

    $servidor = "localhost";
    $banco = "labs";
    $usuario = "root";
    $senha = "";

    $conexao = new mysqli($servidor, $usuario, $senha, $banco);

    if($conexao->connect_error){
        echo "Erro de conexão!" . $conexao->connect_error;
    }else{
        //echo "conectado";
    }
?>