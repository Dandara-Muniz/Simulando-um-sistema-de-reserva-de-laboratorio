CREATE DATABASE labs;

USE labs;

CREATE TABLE tb_professores (
cd_professor INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nm_professor VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE tb_turmas (
cd_turma INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nm_curso_turma VARCHAR(50) NOT NULL,
nm_professor VARCHAR(50) NOT NULL,
FOREIGN KEY (nm_professor) REFERENCES tb_professores(nm_professor)
);

CREATE TABLE tb_laboratorios (
cd_laboratorio INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
sg_numero_laboratorio CHAR(2) NOT NULL UNIQUE,
st_laboratorio VARCHAR(12) NOT NULL
);

CREATE TABLE tb_reservas (
cd_reserva INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
hr_inicio_reserva TIME NOT NULL,
hr_fim_reserva TIME NOT NULL,
nm_professor VARCHAR(50) NOT NULL,
nm_curso_turma INT NOT NULL,
sg_numero_laboratorio INT NOT NULL,
FOREIGN KEY (nm_professor) REFERENCES tb_professores(nm_professor),
FOREIGN KEY (nm_curso_turma) REFERENCES tb_turmas(cd_turma),
FOREIGN KEY (sg_numero_laboratorio) REFERENCES tb_laboratorios(cd_laboratorio)
);

CREATE TABLE tb_funcionarios (
cd_funcionario INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nm_funcionario VARCHAR(50) NOT NULL,
ds_senha_funcionario  VARCHAR(255) NOT NULL
);

INSERT INTO tb_professores(nm_professor) VALUES ('Matheus'), ('Oswaldo'), ('Augusto'), ('Wellington');

INSERT INTO tb_turmas(nm_curso_turma,nm_professor) VALUES 
('Desenvolviemnto de sistemas', 'Matheus'), 
('Desenvolviemnto de sistemas', 'Oswaldo'),
('Desenvolviemnto de sistemas', 'Augusto'),
('Administração', 'Wellington');

INSERT INTO tb_laboratorios(sg_numero_laboratorio, st_laboratorio) VALUES 
('01', 'Disponível'),
('02', 'Disponível'),
('03', 'Disponível'),
('04', 'Disponível'),
('05', 'Disponível'),
('06', 'Disponível');

INSERT INTO tb_funcionarios(nm_funcionario, ds_senha_funcionario) VALUES ('Felipe', '@senha123');