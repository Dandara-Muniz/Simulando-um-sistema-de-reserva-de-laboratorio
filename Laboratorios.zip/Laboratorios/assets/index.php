<?php
session_start();
include('../inc/conexao.php');


$sql = "SELECT * FROM tb_funcionarios";
$resultado = $conexao->query($sql);
//

if (isset($_POST['verificacao'])) {
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    $sql = "SELECT nm_funcionario, ds_senha_funcionario from tb_funcionarios WHERE nm_funcionario = ?;";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $nome);
    $stmt->execute();

    //resultado da busca
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        // dados do funcionário encontrado 
        $usuario = $resultado->fetch_assoc();

        // Verifica se a senha do form bate com a salva no banco
        if (password_verify($senha, $usuario['ds_senha_funcionario']) || $senha === $usuario['ds_senha_funcionario']) {
            header("Location: labs.php");
        } else {
            $mensagem = "SENHA INCORRETA!";
        }
    } else {
        $mensagem = "USUÁRIO NÃO ENCONTRADO!";
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Login do sistema</title>
</head>

<body>
    <div class="container-login">
        <?php if (!empty($mensagem)): ?>
            <p style="color: red; font-weight: bold;"><?php echo $mensagem; ?></p>
        <?php endif; ?>
        <div class="row-login">
            <form action="index.php" method="post">
                <label for="nome">Nome do funcionário:</label>
                <input type="text" name="nome">
                <label for="senha">Senha de entrada:</label>
                <input type="text" name="senha">
                <input type="submit" value="Realizar entrada" name="verificacao">
            </form>
        </div>
    </div>
</body>

</html>