<?php
session_start();
include('../inc/conexao.php');

$sql = "SELECT * FROM tb_funcionarios";
$resultado = $conexao->query($sql);
//

if (isset($_POST['verificacao'])) {
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    $sql = "SELECT nm_funcionario, ds_senha_funcionario from tb_funcionarios WHERE nm_funcionario = ?;";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $nome);
    $stmt->execute();

    //resultado da busca
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        // dados do funcionário encontrado 
        $usuario = $resultado->fetch_assoc();

        // Verifica se a senha do form bate com a salva no banco
        if (password_verify($senha, $usuario['ds_senha_funcionario']) || $senha === $usuario['ds_senha_funcionario']) {
            header("Location: labs.php");
        } else {
            $mensagem = "SENHA INCORRETA!";
        }
    } else {
        $mensagem = "USUÁRIO NÃO ENCONTRADO!";
    }
}

?>
