<?php
session_start();
include('../inc/conexao.php');


$sql = "SELECT * FROM tb_laboratorios";

$resultado = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Laboratórios de informática</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="btn-group w-100 mb-3" role="group" aria-label="Basic example">
                <a class="btn btn-secondary" href="horarios.php"> <i class="fa-solid fa-clock"></i>Horarios</a>
                <a class="btn btn-secondary" href="labs.php"><i class="fa-solid fa-computer"></i>Laboratorios
                    disponiveis</a>
                <a class="btn btn-secondary" href="reservas.php"><i
                        class="fa-slab-press-duo fa-regular fa-calendar"></i>Realizar
                    reserva</a>
            </div>

            <div class="container-conteudo">
                <div class="row-conteudo">
                    <table class="table table-striped">
                        <thead class="table-primary">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Laboratório</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                               <?php
                                if ($resultado->num_rows > 0) {
                                    $i = 1;
                                    while ($reserva = $resultado->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $i++ . "</td>"; // Exibe o número da linha (#)
                                        echo "<td>" . $reserva['sg_numero_laboratorio'] . "</td>";
                                        echo "<td>" . $reserva['st_laboratorio'] . "</td>";
                                       echo "</tr>";
                                    }
                                } else {
                                    echo "<tr>";
                                    echo "<td colspan='6' style='text-align: center;'>Não há dados inseridos</td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
</body>

</html>