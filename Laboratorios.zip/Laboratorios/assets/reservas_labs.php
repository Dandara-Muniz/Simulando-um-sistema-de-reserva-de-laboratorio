<?php
session_start();
include('../inc/conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // procura o cd_laboratorio a partir da sigla
    function getCdLabPorSigla($conexao, $sigla) {
        $stmt = $conexao->prepare("SELECT cd_laboratorio FROM tb_laboratorios WHERE sg_numero_laboratorio = ?");
        $stmt->bind_param("s", $sigla);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        return $res ? $res['cd_laboratorio'] : null;
    }

    // Salva reserva nova
    if (isset($_POST['salvar_reserva'])) {
        $sigla_lab = str_pad(trim($_POST['sg_numero_laboratorio']), 2, "0", STR_PAD_LEFT);
        $professor = trim($_POST['nm_professor']);
        $cd_turma  = (int) $_POST['nm_curso_turma'];
        $hr_inicio = $_POST['hr_inicio_reserva'];
        $hr_fim    = $_POST['hr_fim_reserva'];

        $cd_laboratorio = getCdLabPorSigla($conexao, $sigla_lab);

        if (!$cd_laboratorio) {
            echo "<script>alert('Laboratório não encontrado!'); window.location.href='reservas.php';</script>";
            exit;
        }

        // --- Verificação de horário ---
        $sql_conflito = "SELECT COUNT(*) as total FROM tb_reservas 
                         WHERE sg_numero_laboratorio = ? 
                         AND (? < hr_fim_reserva AND ? > hr_inicio_reserva)";
        
        $stmt_conflito = $conexao->prepare($sql_conflito);
        $stmt_conflito->bind_param("iss", $cd_laboratorio, $hr_inicio, $hr_fim);
        $stmt_conflito->execute();
        $conflito = $stmt_conflito->get_result()->fetch_assoc()['total'];

        if ($conflito > 0) {
            echo "<script>alert('Atenção: Este laboratório já possui uma reserva ativa neste horário!'); window.location.href='reservas.php';</script>";
            exit;
        }

        // Insere a nova reserva
        $sql_insert = "INSERT INTO tb_reservas (sg_numero_laboratorio, nm_professor, nm_curso_turma, hr_inicio_reserva, hr_fim_reserva) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        $stmt->bind_param("isiss", $cd_laboratorio, $professor, $cd_turma, $hr_inicio, $hr_fim);

        if ($stmt->execute()) {

            // Marca como Indisponível
            $sql_update_lab = "UPDATE tb_laboratorios SET st_laboratorio = 'Indisponível' WHERE sg_numero_laboratorio = ?";
            $stmt_lab = $conexao->prepare($sql_update_lab);
            $stmt_lab->bind_param("s", $sigla_lab);
            $stmt_lab->execute();

            echo "<script>alert('Reserva realizada com sucesso!'); window.location.href='reservas.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erro ao realizar reserva: " . addslashes($stmt->error) . "'); window.location.href='reservas.php';</script>";
            exit;
        }
    }

    // Atualiza reserva
    if (isset($_POST['atualizar_reserva'])) {
        $cd_reserva      = (int) $_POST['cd_reserva'];
        $sigla_lab_nova  = str_pad(trim($_POST['sg_numero_laboratorio']), 2, "0", STR_PAD_LEFT);
        $professor       = trim($_POST['nm_professor']);
        $cd_turma        = (int) $_POST['nm_curso_turma'];
        $hr_inicio       = $_POST['hr_inicio_reserva'];
        $hr_fim          = $_POST['hr_fim_reserva'];

        $cd_lab_novo = getCdLabPorSigla($conexao, $sigla_lab_nova);

        if (!$cd_lab_novo) {
            echo "<script>alert('Laboratório não encontrado!'); window.location.href='reservas.php';</script>";
            exit;
        }

        // Verificação de horário ---
        $sql_conflito = "SELECT COUNT(*) as total FROM tb_reservas 
                         WHERE sg_numero_laboratorio = ? 
                         AND cd_reserva != ? 
                         AND (? < hr_fim_reserva AND ? > hr_inicio_reserva)";
        
        $stmt_conflito = $conexao->prepare($sql_conflito);
        $stmt_conflito->bind_param("iiss", $cd_lab_novo, $cd_reserva, $hr_inicio, $hr_fim);
        $stmt_conflito->execute();
        $conflito = $stmt_conflito->get_result()->fetch_assoc()['total'];

        if ($conflito > 0) {
            echo "<script>alert('Atenção: O laboratório selecionado já possui outra reserva neste horário!'); window.location.href='reservas.php';</script>";
            exit;
        }

        // Busca sg e cd antigos
        $sql_busca_antigo = "SELECT r.sg_numero_laboratorio as cd_lab, l.sg_numero_laboratorio as sigla 
                             FROM tb_reservas r 
                             INNER JOIN tb_laboratorios l ON r.sg_numero_laboratorio = l.cd_laboratorio 
                             WHERE r.cd_reserva = ?";
        $stmt_busca = $conexao->prepare($sql_busca_antigo);
        $stmt_busca->bind_param("i", $cd_reserva);
        $stmt_busca->execute();
        $res_antigo = $stmt_busca->get_result()->fetch_assoc();

        $sigla_lab_antiga = $res_antigo['sigla'] ?? null;
        $cd_lab_antigo    = $res_antigo['cd_lab'] ?? null;

        // Atualiza a reserva
        $sql_update = "UPDATE tb_reservas 
                       SET sg_numero_laboratorio = ?, 
                           nm_professor = ?, 
                           nm_curso_turma = ?, 
                           hr_inicio_reserva = ?, 
                           hr_fim_reserva = ? 
                       WHERE cd_reserva = ?";

        $stmt = $conexao->prepare($sql_update);
        $stmt->bind_param("isissi", $cd_lab_novo, $professor, $cd_turma, $hr_inicio, $hr_fim, $cd_reserva);

        if ($stmt->execute()) {

            // Se trocou de laboratório, atualiza o status dos envolvidos
            if ($sigla_lab_antiga && $sigla_lab_antiga !== $sigla_lab_nova) {

                // Libera o antigo se não houver outras reservas 
                $sql_check = "SELECT COUNT(*) as total FROM tb_reservas WHERE sg_numero_laboratorio = ? AND cd_reserva != ?";
                $stmt_check = $conexao->prepare($sql_check);
                $stmt_check->bind_param("ii", $cd_lab_antigo, $cd_reserva);
                $stmt_check->execute();
                $total_outras = $stmt_check->get_result()->fetch_assoc()['total'];

                if ($total_outras == 0) {
                    $sql_libera = "UPDATE tb_laboratorios SET st_laboratorio = 'Disponível' WHERE sg_numero_laboratorio = ?";
                    $stmt_libera = $conexao->prepare($sql_libera);
                    $stmt_libera->bind_param("s", $sigla_lab_antiga);
                    $stmt_libera->execute();
                }

                // Ocupa o novo
                $sql_ocupa = "UPDATE tb_laboratorios SET st_laboratorio = 'Indisponível' WHERE sg_numero_laboratorio = ?";
                $stmt_ocupa = $conexao->prepare($sql_ocupa);
                $stmt_ocupa->bind_param("s", $sigla_lab_nova);
                $stmt_ocupa->execute();
            }

            echo "<script>alert('Reserva atualizada com sucesso!'); window.location.href='reservas.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erro ao atualizar reserva: " . addslashes($stmt->error) . "'); window.location.href='reservas.php';</script>";
            exit;
        }
    }
}
?>