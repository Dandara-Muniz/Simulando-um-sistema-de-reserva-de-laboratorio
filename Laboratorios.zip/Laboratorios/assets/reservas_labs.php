<?php
session_start();
include('../inc/conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    // Salvar Reserva
    if (isset($_POST['salvar_reserva'])) {
        $laboratorio = $_POST['sg_numero_laboratorio'];
        $professor = $_POST['nm_professor'];
        $turma = $_POST['nm_curso_turma'];
        $hr_inicio = $_POST['hr_inicio_reserva'];
        $hr_fim = $_POST['hr_fim_reserva'];

        $sql_insert = "INSERT INTO tb_reservas (sg_numero_laboratorio, nm_professor, nm_curso_turma, hr_inicio_reserva, hr_fim_reserva) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);

        $stmt->bind_param("sssss", $laboratorio, $professor, $turma, $hr_inicio, $hr_fim);


        if ($stmt->execute()) {

            // Atualiza status na tabela labs
            $sql_update_lab = "UPDATE tb_laboratorios SET st_laboratorio = 'Indisponível' WHERE sg_numero_laboratorio = ?";
            $stmt_lab = $conexao->prepare($sql_update_lab);
            $stmt_lab->bind_param("s", $laboratorio);
            $stmt_lab->execute();

            echo "<script>alert('Reserva realizada com sucesso!'); window.location.href='reservas.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erro ao realizar reserva: " . addslashes($stmt->error) . "'); window.location.href='reservas.php';</script>";
            exit;
        }
    }

    // Atualizar Reserva
    if (isset($_POST['atualizar_reserva'])) {
        $cd_reserva = $_POST['cd_reserva'];
        $laboratorio_novo = $_POST['sg_numero_laboratorio'];
        $professor = $_POST['nm_professor'];
        $turma = $_POST['nm_curso_turma'];
        $hr_inicio = $_POST['hr_inicio_reserva'];
        $hr_fim = $_POST['hr_fim_reserva'];

        // Consulta o lab atual antes de modificar a reserva
        $sql_busca_antigo = "SELECT sg_numero_laboratorio FROM tb_reservas WHERE cd_reserva = ?";
        $stmt_busca = $conexao->prepare($sql_busca_antigo);
        $stmt_busca->bind_param("i", $cd_reserva);
        $stmt_busca->execute();
        $res_antigo = $stmt_busca->get_result()->fetch_assoc();
        $laboratorio_antigo = $res_antigo['sg_numero_laboratorio'] ?? null;

        // Atualiza a reserva
        $sql_update = "UPDATE tb_reservas 
                   SET sg_numero_laboratorio = ?, 
                       nm_professor = ?, 
                       nm_curso_turma = ?, 
                       hr_inicio_reserva = ?, 
                       hr_fim_reserva = ? 
                   WHERE cd_reserva = ?";

        $stmt = $conexao->prepare($sql_update);
        $stmt->bind_param("sssssi", $laboratorio_novo, $professor, $turma, $hr_inicio, $hr_fim, $cd_reserva);

        if ($stmt->execute()) {
            // Se lab alterado, atualiza o status dos dois
            if ($laboratorio_antigo && $laboratorio_antigo !== $laboratorio_novo) {

                // Libera o lab antigo
                $sql_libera = "UPDATE tb_laboratorios SET st_laboratorio = 'Disponível' WHERE sg_numero_laboratorio = ?";
                $stmt_libera = $conexao->prepare($sql_libera);
                $stmt_libera->bind_param("s", $laboratorio_antigo);
                $stmt_libera->execute();

                // Ocupa o novo lab
                $sql_ocupa = "UPDATE tb_laboratorios SET st_laboratorio = 'Indisponível' WHERE sg_numero_laboratorio = ?";
                $stmt_ocupa = $conexao->prepare($sql_ocupa);
                $stmt_ocupa->bind_param("s", $laboratorio_novo);
                $stmt_ocupa->execute();
            }

            echo "<script>alert('Reserva atualizada com sucesso!'); window.location.href='reservas.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erro ao atualizar reserva: " . addslashes($stmt->error) . "'); window.location.href='reservas.php';</script>";
            exit;
        }
    }
}
?>