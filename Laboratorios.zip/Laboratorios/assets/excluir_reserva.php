<?php
include('../inc/conexao.php');
    if (isset($_POST['excluir_reserva'])) {
        $cd_reserva = (int) $_POST['cd_reserva'];

        // Busca qual era o laboratório antes de deletar
        $sql_busca = "SELECT sg_numero_laboratorio FROM tb_reservas WHERE cd_reserva = ?";
        $stmt_busca = $conexao->prepare($sql_busca);
        $stmt_busca->bind_param("i", $cd_reserva);
        $stmt_busca->execute();
        $res = $stmt_busca->get_result()->fetch_assoc();

        $cd_laboratorio = $res['sg_numero_laboratorio'] ?? null;

        // Deleta a reserva
        $sql_delete = "DELETE FROM tb_reservas WHERE cd_reserva = ?";
        $stmt_delete = $conexao->prepare($sql_delete);
        $stmt_delete->bind_param("i", $cd_reserva);

        if ($stmt_delete->execute()) {

            if ($cd_laboratorio) {
                
                // Verifica se o laboratório ainda possui OUTRA reserva
                $sql_check = "SELECT COUNT(*) as total FROM tb_reservas WHERE sg_numero_laboratorio = ?";
                $stmt_check = $conexao->prepare($sql_check);
                $stmt_check->bind_param("i", $cd_laboratorio);
                $stmt_check->execute();
                $total_outras = $stmt_check->get_result()->fetch_assoc()['total'];

                // Se não houver mais reservas para esse lab, volta o status para 'Disponível'
                if ($total_outras == 0) {
                    $sql_libera = "UPDATE tb_laboratorios SET st_laboratorio = 'Disponível' WHERE cd_laboratorio = ?";
                    $stmt_libera = $conexao->prepare($sql_libera);
                    $stmt_libera->bind_param("i", $cd_laboratorio);
                    $stmt_libera->execute();
                }
            }

            echo "<script>alert('Reserva excluída com sucesso!'); window.location.href='reservas.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erro ao excluir reserva: " . addslashes($stmt_delete->error) . "'); window.location.href='reservas.php';</script>";
            exit;
        }
    }
    ?>