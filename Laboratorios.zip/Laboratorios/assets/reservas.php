<?php
session_start();
include('../inc/conexao.php');

// Buscar para carregar os selects
$professores = $conexao->query("SELECT nm_professor FROM tb_professores");
$turmas = $conexao->query("SELECT MAX(cd_turma) as cd_turma, nm_curso_turma FROM tb_turmas GROUP BY nm_curso_turma");
$laboratorios = $conexao->query("SELECT cd_laboratorio, sg_numero_laboratorio FROM tb_laboratorios");

// Buscar reservas 
$sql = "SELECT r.cd_reserva, 
               l.sg_numero_laboratorio, 
               r.nm_professor, 
               t.cd_turma,              
               t.nm_curso_turma, 
               r.hr_inicio_reserva, 
               r.hr_fim_reserva
        FROM tb_reservas r
        INNER JOIN tb_turmas t ON r.nm_curso_turma = t.cd_turma
        INNER JOIN tb_laboratorios l ON r.sg_numero_laboratorio = l.sg_numero_laboratorio";

$resultado = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Laboratórios - Reservas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="btn-group w-100 mb-3" role="group">
                <a class="btn btn-secondary" href="horarios.php"><i class="fa-solid fa-clock"></i> Horários</a>
                <a class="btn btn-secondary" href="labs.php"><i class="fa-solid fa-computer"></i> Laboratórios
                    disponíveis</a>
                <a class="btn btn-secondary active" href="reservas.php"><i class="fa-regular fa-calendar"></i> Realizar
                    reserva</a>
            </div>

            <div class="container-conteudo">
                <div class="row-conteudo">
                    <button type="button" class="btn btn-secondary mb-3" data-bs-toggle="modal"
                        data-bs-target="#modalReserva">
                        <i class="fa-solid fa-pen-to-square"></i> Realizar reserva
                    </button>

                    <!-- Modal Nova Reserva -->
                    <div class="modal fade" id="modalReserva" tabindex="-1" aria-labelledby="modalReservaLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" style="max-width: 600px; width: 100%;">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-dark" id="modalReservaLabel">Nova Reserva</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <form action="reservas_labs.php" method="POST">
                                    <div class="modal-body text-start"
                                        style="box-sizing: border-box; overflow: hidden;">

                                        <!-- Laboratório -->
                                        <div class="mb-3">
                                            <label for="sg_numero_laboratorio"
                                                class="form-label text-dark fw-bold">Laboratório:</label>
                                            <select class="form-select" name="sg_numero_laboratorio" required>
                                                <option value="">Selecione o laboratório...</option>
                                                <?php
                                                $laboratorios->data_seek(0);
                                                while ($lab = $laboratorios->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= htmlspecialchars($lab['sg_numero_laboratorio']) ?>">
                                                        Laboratório <?= htmlspecialchars($lab['sg_numero_laboratorio']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <!-- Professor -->
                                        <div class="mb-3">
                                            <label for="nm_professor"
                                                class="form-label text-dark fw-bold">Professor:</label>
                                            <select class="form-select" name="nm_professor" required>
                                                <option value="">Selecione o professor...</option>
                                                <?php
                                                $professores->data_seek(0);
                                                while ($prof = $professores->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= htmlspecialchars($prof['nm_professor']) ?>">
                                                        <?= htmlspecialchars($prof['nm_professor']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <!-- Turma -->
                                        <div class="mb-3">
                                            <label for="nm_curso_turma" class="form-label text-dark fw-bold">Turma
                                                (curso):</label>
                                            <select class="form-select" name="nm_curso_turma" required>
                                                <option value="">Selecione a turma...</option>
                                                <?php
                                                $turmas->data_seek(0);
                                                while ($turma = $turmas->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= $turma['cd_turma'] ?>">
                                                        <?= htmlspecialchars($turma['nm_curso_turma']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <!-- Horários -->
                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Horário de Início:</label>
                                            <input type="time" class="form-control" name="hr_inicio_reserva" required>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Horário de Fim:</label>
                                            <input type="time" class="form-control" name="hr_fim_reserva" required>
                                        </div>

                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" name="salvar_reserva" class="btn btn-primary">Salvar
                                            Reserva</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Editar Reserva -->
                    <div class="modal fade" id="modalEditarReserva" tabindex="-1"
                        aria-labelledby="modalEditarReservaLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" style="max-width: 600px; width: 100%;">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-dark" id="modalEditarReservaLabel">Editar Reserva</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <form action="reservas_labs.php" method="POST">
                                    <input type="hidden" name="cd_reserva" id="edit_cd_reserva">

                                    <div class="modal-body text-start">
                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Laboratório:</label>
                                            <select class="form-select" name="sg_numero_laboratorio"
                                                id="edit_sg_numero_laboratorio" required>
                                                <option value="">Selecione o laboratório...</option>
                                                <?php
                                                $laboratorios->data_seek(0);
                                                while ($lab = $laboratorios->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= htmlspecialchars($lab['sg_numero_laboratorio']) ?>">
                                                        Laboratório <?= htmlspecialchars($lab['sg_numero_laboratorio']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Professor:</label>
                                            <select class="form-select" name="nm_professor" id="edit_nm_professor"
                                                required>
                                                <option value="">Selecione o professor...</option>
                                                <?php
                                                $professores->data_seek(0);
                                                while ($prof = $professores->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= htmlspecialchars($prof['nm_professor']) ?>">
                                                        <?= htmlspecialchars($prof['nm_professor']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Turma (curso):</label>
                                            <select class="form-select" name="nm_curso_turma" id="edit_nm_curso_turma"
                                                required>
                                                <option value="">Selecione a turma...</option>
                                                <?php
                                                $turmas->data_seek(0);
                                                while ($turma = $turmas->fetch_assoc()):
                                                    ?>
                                                    <option value="<?= $turma['cd_turma'] ?>">
                                                        <?= htmlspecialchars($turma['nm_curso_turma']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Horário de Início:</label>
                                            <input type="time" class="form-control" name="hr_inicio_reserva"
                                                id="edit_hr_inicio_reserva" required>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label text-dark fw-bold">Horário de Fim:</label>
                                            <input type="time" class="form-control" name="hr_fim_reserva"
                                                id="edit_hr_fim_reserva" required>
                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" name="atualizar_reserva" class="btn btn-primary">Atualizar
                                            Reserva</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                    <!-- Modal Excluir Reserva -->
                    <div class="modal fade" id="modalExcluirReserva" tabindex="-1"
                        aria-labelledby="modalExcluirReservaLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content text-dark">
                                <div class="modal-header bg-danger text-white">
                                    <h5 class="modal-title" id="modalExcluirReservaLabel">
                                        <i class="fa-solid fa-triangle-exclamation"></i> Confirmar Exclusão
                                    </h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="excluir_reserva.php" method="POST">
                                    <input type="hidden" name="cd_reserva" id="delete_cd_reserva">
                                    <div class="modal-body text-start">
                                        <p class="text-dark mb-2">Tem certeza de que deseja excluir a seguinte reserva?
                                        </p>
                                        <ul class="text-dark">
                                            <li><strong>Laboratório:</strong> <span id="delete_lab"></span></li>
                                            <li><strong>Professor:</strong> <span id="delete_professor"></span></li>
                                        </ul>
                                        <p class="text-danger mb-0"><small>* Esta ação não poderá ser desfeita.</small>
                                        </p>
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" name="excluir_reserva"
                                            class="btn btn-danger">Excluir</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                    <!-- Tabela -->
                    <table class="table table-striped table-hover">
                        <thead class="table-primary">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Laboratório</th>
                                <th scope="col">Professor</th>
                                <th scope="col">Turma</th>
                                <th scope="col">Período no laboratório</th>
                                <th scope="col">Alterar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($resultado && $resultado->num_rows > 0) {
                                $cont = 1;
                                while ($reserva = $resultado->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $cont++ . "</td>";
                                    echo "<td>" . htmlspecialchars($reserva['sg_numero_laboratorio']) . "</td>";
                                    echo "<td>" . htmlspecialchars($reserva['nm_professor']) . "</td>";
                                    echo "<td>" . htmlspecialchars($reserva['nm_curso_turma']) . "</td>";
                                    echo "<td>" . (strtotime($reserva['hr_fim_reserva']) - strtotime($reserva['hr_inicio_reserva'])) / 3600 . " horas</td>";
                                    echo "<td>";
                                    echo "  <button type='button' class='btn btn-sm btn-warning btn-editar' ";
                                    echo "          data-bs-toggle='modal' ";
                                    echo "          data-bs-target='#modalEditarReserva' ";
                                    echo "          data-id='" . $reserva['cd_reserva'] . "' ";
                                    echo "          data-lab='" . htmlspecialchars($reserva['sg_numero_laboratorio']) . "' ";
                                    echo "          data-professor='" . htmlspecialchars($reserva['nm_professor'], ENT_QUOTES) . "' ";
                                    echo "          data-turma='" . $reserva['cd_turma'] . "' ";
                                    echo "          data-inicio='" . $reserva['hr_inicio_reserva'] . "' ";
                                    echo "          data-fim='" . $reserva['hr_fim_reserva'] . "'>";
                                    echo "      <i class='fa-solid fa-pen-to-square'></i> Editar";
                                    echo "  </button>";
                                    echo "  <button type='button' class='btn btn-sm btn-danger btn-excluir' ";
                                    echo "          data-bs-toggle='modal' ";
                                    echo "          data-bs-target='#modalExcluirReserva' ";
                                    echo "          data-id='" . $reserva['cd_reserva'] . "' ";
                                    echo "          data-lab='" . htmlspecialchars($reserva['sg_numero_laboratorio']) . "' ";
                                    echo "          data-professor='" . htmlspecialchars($reserva['nm_professor'], ENT_QUOTES) . "'>";
                                    echo "      <i class='fa-solid fa-trash'></i> Excluir";
                                    echo "  </button>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center'>Não há reservas registradas.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.btn-editar').forEach(button => {
            button.addEventListener('click', function () {
                document.getElementById('edit_cd_reserva').value = this.getAttribute('data-id');
                document.getElementById('edit_sg_numero_laboratorio').value = this.getAttribute('data-lab');
                document.getElementById('edit_nm_professor').value = this.getAttribute('data-professor');
                document.getElementById('edit_nm_curso_turma').value = this.getAttribute('data-turma');
                document.getElementById('edit_hr_inicio_reserva').value = this.getAttribute('data-inicio');
                document.getElementById('edit_hr_fim_reserva').value = this.getAttribute('data-fim');
            });
        });
        
        document.querySelectorAll('.btn-excluir').forEach(button => {
            button.addEventListener('click', function () {
                document.getElementById('delete_cd_reserva').value = this.getAttribute('data-id');
                document.getElementById('delete_lab').textContent = this.getAttribute('data-lab');
                document.getElementById('delete_professor').textContent = this.getAttribute('data-professor');
            });
        });
    </script>
    </script>
</body>

</html>